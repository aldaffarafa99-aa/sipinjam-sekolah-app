@extends('layouts.app')
@section('title', 'Laporan Peminjaman')
@section('content')
@php($statusLabels = ['pending' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak', 'dipinjam' => 'Dipinjam', 'terlambat' => 'Terlambat', 'selesai' => 'Selesai'])
<div class="page-hero mb-4"><div><div class="page-kicker">Analitik inventaris</div><h3 class="mb-1">Laporan Peminjaman</h3><p class="mb-0">Filter aktivitas dan unduh data dalam format CSV.</p></div><a class="btn btn-primary" href="{{ route('laporan.export', request()->query()) }}"><i class="bi bi-download me-1"></i>Unduh CSV</a></div>
<div class="row g-3 mb-4"><div class="col-md-6"><div class="stat-card"><div><div class="stat-label">Transaksi</div><div class="stat-value">{{ $totalPinjaman }}</div></div></div></div><div class="col-md-6"><div class="stat-card"><div><div class="stat-label">Unit dipinjam</div><div class="stat-value">{{ $totalUnit }}</div></div></div></div></div>
<form method="GET" class="filter-panel mb-3"><div class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Tanggal mulai</label><input type="date" name="tanggal_mulai" value="{{ request('tanggal_mulai') }}" class="form-control"></div><div class="col-md-3"><label class="form-label">Tanggal selesai</label><input type="date" name="tanggal_selesai" value="{{ request('tanggal_selesai') }}" class="form-control"></div><div class="col-md-3"><label class="form-label">Status</label><select name="status" class="form-select"><option value="">Semua status</option>@foreach($statusLabels as $status => $label)<option value="{{ $status }}" @selected(request('status') === $status)>{{ $label }}</option>@endforeach</select></div><div class="col-md-3"><label class="form-label">Peminjam / barang</label><input name="search" value="{{ request('search') }}" class="form-control"></div><div class="col-12"><button class="btn btn-dark">Terapkan filter</button><a href="{{ route('laporan.index') }}" class="btn btn-light">Reset</a></div></div></form>
<div class="data-card table-responsive">
    <table class="table mb-0 align-middle">
        <thead>
            <tr><th>NO</th><th>Peminjam</th><th>Barang</th><th>Jumlah</th><th>Tanggal pinjam</th><th>Jatuh tempo</th><th>Status</th></tr>
        </thead>
        <tbody>
            @forelse($peminjaman as $item)
                <tr>
                    <td>{{ $peminjaman->firstItem() + $loop->index }}</td>
                    <td>{{ $item->nama_peminjam }}<small class="d-block text-muted">{{ $item->kelas_jabatan }}</small></td>
                    <td>{{ $item->barang?->nama_barang ?? 'Barang dihapus' }}</td>
                    <td>{{ $item->jumlah }}</td>
                    <td>{{ $item->tanggal_pinjam->locale('id')->translatedFormat('d M Y') }}</td>
                    <td>{{ $item->tanggal_kembali_rencana->locale('id')->translatedFormat('d M Y') }}</td>
                    <td><x-status-badge :status="$item->status_tampil" /></td>
                </tr>
            @empty
                <tr><td colspan="7" class="text-center text-muted py-4">Tidak ada transaksi pada filter ini.</td></tr>
            @endforelse
        </tbody>
    </table>
</div>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mt-3">
    <small class="text-muted">
        Menampilkan {{ $peminjaman->firstItem() ?? 0 }}–{{ $peminjaman->lastItem() ?? 0 }} dari {{ $peminjaman->total() }} transaksi
    </small>
    {{ $peminjaman->links('pagination::bootstrap-5') }}
</div>
@endsection
