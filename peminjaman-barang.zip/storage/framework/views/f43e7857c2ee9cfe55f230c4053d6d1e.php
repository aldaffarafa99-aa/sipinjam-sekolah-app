<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $statusKey = $status === 'dikembalikan' ? 'selesai' : $status;
    $statusLabels = [
        'pending' => 'Menunggu',
        'disetujui' => 'Disetujui',
        'ditolak' => 'Ditolak',
        'dipinjam' => 'Dipinjam',
        'terlambat' => 'Terlambat',
        'selesai' => 'Selesai',
    ];
    $statusClass = array_key_exists($statusKey, $statusLabels) ? $statusKey : 'unknown';
    $statusLabel = $statusLabels[$statusKey] ?? 'Status tidak dikenal';
?>

<span <?php echo e($attributes->class(['system-status', 'system-status--' . $statusClass])); ?>><?php echo e($statusLabel); ?></span>
<?php /**PATH C:\Users\Advan\OneDrive\Desktop\coding\peminjaman-barang\resources\views/components/status-badge.blade.php ENDPATH**/ ?>