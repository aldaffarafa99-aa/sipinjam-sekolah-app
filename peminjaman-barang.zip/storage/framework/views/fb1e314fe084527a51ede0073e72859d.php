
<?php $__env->startSection('title', 'Laporan Peminjaman'); ?>
<?php $__env->startSection('content'); ?>
<?php ($statusLabels = ['pending' => 'Menunggu', 'disetujui' => 'Disetujui', 'ditolak' => 'Ditolak', 'dipinjam' => 'Dipinjam', 'terlambat' => 'Terlambat', 'selesai' => 'Selesai']); ?>
<div class="page-hero mb-4"><div><div class="page-kicker">Analitik inventaris</div><h3 class="mb-1">Laporan Peminjaman</h3><p class="mb-0">Filter aktivitas dan unduh data dalam format CSV.</p></div><a class="btn btn-primary" href="<?php echo e(route('laporan.export', request()->query())); ?>"><i class="bi bi-download me-1"></i>Unduh CSV</a></div>
<div class="row g-3 mb-4"><div class="col-md-6"><div class="stat-card"><div><div class="stat-label">Transaksi</div><div class="stat-value"><?php echo e($totalPinjaman); ?></div></div></div></div><div class="col-md-6"><div class="stat-card"><div><div class="stat-label">Unit dipinjam</div><div class="stat-value"><?php echo e($totalUnit); ?></div></div></div></div></div>
<form method="GET" class="filter-panel mb-3"><div class="row g-2 align-items-end"><div class="col-md-3"><label class="form-label">Tanggal mulai</label><input type="date" name="tanggal_mulai" value="<?php echo e(request('tanggal_mulai')); ?>" class="form-control"></div><div class="col-md-3"><label class="form-label">Tanggal selesai</label><input type="date" name="tanggal_selesai" value="<?php echo e(request('tanggal_selesai')); ?>" class="form-control"></div><div class="col-md-3"><label class="form-label">Status</label><select name="status" class="form-select"><option value="">Semua status</option><?php $__currentLoopData = $statusLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div><div class="col-md-3"><label class="form-label">Peminjam / barang</label><input name="search" value="<?php echo e(request('search')); ?>" class="form-control"></div><div class="col-12"><button class="btn btn-dark">Terapkan filter</button><a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-light">Reset</a></div></div></form>
<div class="data-card table-responsive">
    <table class="table mb-0 align-middle">
        <thead>
            <tr><th>NO</th><th>Peminjam</th><th>Barang</th><th>Jumlah</th><th>Tanggal pinjam</th><th>Jatuh tempo</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($peminjaman->firstItem() + $loop->index); ?></td>
                    <td><?php echo e($item->nama_peminjam); ?><small class="d-block text-muted"><?php echo e($item->kelas_jabatan); ?></small></td>
                    <td><?php echo e($item->barang?->nama_barang ?? 'Barang dihapus'); ?></td>
                    <td><?php echo e($item->jumlah); ?></td>
                    <td><?php echo e($item->tanggal_pinjam->locale('id')->translatedFormat('d M Y')); ?></td>
                    <td><?php echo e($item->tanggal_kembali_rencana->locale('id')->translatedFormat('d M Y')); ?></td>
                    <td><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $item->status_tampil]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->status_tampil)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Tidak ada transaksi pada filter ini.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mt-3">
    <small class="text-muted">
        Menampilkan <?php echo e($peminjaman->firstItem() ?? 0); ?>–<?php echo e($peminjaman->lastItem() ?? 0); ?> dari <?php echo e($peminjaman->total()); ?> transaksi
    </small>
    <?php echo e($peminjaman->links('pagination::bootstrap-5')); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Advan\OneDrive\Desktop\coding\peminjaman-barang\resources\views/laporan/index.blade.php ENDPATH**/ ?>