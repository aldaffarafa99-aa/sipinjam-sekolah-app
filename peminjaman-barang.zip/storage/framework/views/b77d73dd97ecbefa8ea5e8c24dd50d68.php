
<?php $__env->startSection('title', 'Kategori Barang'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-hero mb-4"><div><div class="page-kicker">Data master</div><h3 class="mb-1">Kategori Barang</h3><p class="mb-0">Kelompokkan inventaris agar mudah dicari.</p></div><a href="<?php echo e(route('kategori.create')); ?>" class="btn btn-primary"><i class="bi bi-plus-lg me-1"></i>Tambah kategori</a></div>
<div class="data-card table-responsive"><table class="table mb-0 align-middle"><thead><tr><th>Nama</th><th>Deskripsi</th><th>Barang</th><th class="text-end">Aksi</th></tr></thead><tbody>
<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($item->nama); ?></td><td><?php echo e($item->deskripsi ?? '-'); ?></td><td><?php echo e($item->barangs_count); ?></td><td class="text-end text-nowrap"><a class="btn btn-sm btn-light" href="<?php echo e(route('kategori.edit', $item)); ?>">Edit</a><form class="d-inline" method="POST" action="<?php echo e(route('kategori.destroy', $item)); ?>" onsubmit="return confirm('Hapus kategori ini?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm btn-outline-danger">Hapus</button></form></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="text-center text-muted py-4">Belum ada kategori.</td></tr><?php endif; ?>
</tbody></table></div><div class="mt-3"><?php echo e($items->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Advan\OneDrive\Desktop\coding\peminjaman-barang\resources\views/master-data/kategori/index.blade.php ENDPATH**/ ?>