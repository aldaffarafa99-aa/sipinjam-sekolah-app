<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Barang | Inventaris Sekolah</title>
    <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">
    <link rel="alternate icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="app-shell">

<div class="app-background-shape shape-one"></div>
<div class="app-background-shape shape-two"></div>

<nav class="app-navbar navbar navbar-light">
    <div class="container-fluid app-container">
        <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
            <span class="brand-mark"><img src="<?php echo e(asset('images/logo-sipinjam.jpg')); ?>" alt="Logo SIPINJAM"></span>
            <span><strong>Peminjaman</strong><small>Barang Sekolah</small></span>
        </a>
        <div class="app-primary-nav-wrap">
            <ul class="navbar-nav app-primary-nav">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('dashboard')); ?>"><i class="bi bi-grid-1x2-fill me-2"></i>Dashboard</a>
                </li>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('barang.*') ? 'active' : ''); ?>" href="<?php echo e(route('barang.index')); ?>"><i class="bi bi-box-seam me-2"></i>Data Barang</a>
                    </li>
                    <li class="nav-item dropdown">
                        <button class="nav-link dropdown-toggle border-0 bg-transparent" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-collection me-2"></i>Data Master
                        </button>
                        <ul class="dropdown-menu border-0 shadow">
                            <li><a class="dropdown-item <?php echo e(request()->routeIs('kategori.*') ? 'active' : ''); ?>" href="<?php echo e(route('kategori.index')); ?>"><i class="bi bi-tags me-2"></i>Kategori</a></li>
                            <li><a class="dropdown-item <?php echo e(request()->routeIs('lokasi-barang.*') ? 'active' : ''); ?>" href="<?php echo e(route('lokasi-barang.index')); ?>"><i class="bi bi-geo-alt me-2"></i>Lokasi barang</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('barang.index') ? 'active' : ''); ?>" href="<?php echo e(route('barang.index')); ?>"><i class="bi bi-box-seam me-2"></i>Katalog</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('peminjaman.*') ? 'active' : ''); ?>" href="<?php echo e(route('peminjaman.index')); ?>"><i class="bi bi-arrow-left-right me-2"></i>Peminjaman</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('notifikasi.*') ? 'active' : ''); ?>" href="<?php echo e(route('notifikasi.index')); ?>"><i class="bi bi-bell me-2"></i>Notifikasi <?php if(auth()->user()->unreadNotifications->count()): ?><span class="badge bg-warning text-dark"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span><?php endif; ?></a>
                </li>
                <?php if(auth()->user()->role === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?php echo e(request()->routeIs('laporan.*') ? 'active' : ''); ?>" href="<?php echo e(route('laporan.index')); ?>"><i class="bi bi-file-earmark-bar-graph me-2"></i>Laporan</a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link admin-nav-label"><i class="bi bi-shield-check me-2"></i>Mode Admin</span>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <?php if(auth()->guard()->check()): ?>
        <ul class="navbar-nav app-account-nav">
            <li class="nav-item dropdown profile-nav-item">
                <button type="button" class="profile-nav-link" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Buka menu profil">
                    <?php if(auth()->user()->avatar_path): ?>
                        <img src="<?php echo e(auth()->user()->avatar_url); ?>" alt="Foto profil" class="user-avatar user-avatar-image">
                    <?php else: ?>
                        <span class="user-avatar"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                    <?php endif; ?>
                    <span class="profile-nav-copy">
                        <span class="profile-nav-name"><?php echo e(auth()->user()->name); ?></span>
                        <small class="user-role"><?php echo e(auth()->user()->role === 'admin' ? 'Admin Sarpras' : (auth()->user()->role === 'guru' ? 'Guru' : 'Siswa')); ?></small>
                    </span>
                    <i class="bi bi-chevron-down profile-nav-chevron"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end profile-dropdown border-0 shadow">
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>">
                            <i class="bi bi-person-gear me-2"></i><?php echo e(auth()->user()->role === 'admin' ? 'Profil Admin' : 'Profil Saya'); ?>

                        </a>
                    </li>
                </ul>
            </li>
            <li class="nav-item">
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-logout btn-sm"><i class="bi bi-box-arrow-right me-1"></i>Keluar</button>
                </form>
            </li>
        </ul>
        <?php endif; ?>
    </div>
</nav>

<main class="app-main container-fluid app-container py-4 py-lg-5">
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Advan\OneDrive\Desktop\coding\peminjaman-barang\resources\views/layouts/app.blade.php ENDPATH**/ ?>